function dataqueue_plotter_solution
figure('Name','dataqueue')
hold on

dq = parallel.pool.DataQueue;
afterEach(dq, @plotter)

tic
parfor idx = 1:100
    y = calc(idx);
    send(dq,[idx y])
end
toc
end

function y = calc(x)

it = randn(x);
y = it(1);
pause(0.5)

end

function plotter(data)

plot(data(1),data(2),'o')
shg

end
